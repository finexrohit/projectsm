<h2>Project : Cyber-Bullying Prevention and Detection</h2>
<h3>Team Members: </h3>
<p>KanishKumar K</p>
<p>Satyavarssheni Ra V</p>
<p>Alan Judith A</p>
<p>Cyril Martin S</p>

![image](https://github.com/user-attachments/assets/991f8a7d-8b5a-4071-a994-ff7a878eafb8)

![image](https://github.com/user-attachments/assets/2ea1bfaf-12ba-41a0-bf67-6debccc34f69)

![image](https://github.com/user-attachments/assets/2545c437-a5bd-4e53-9790-95af0ee02b92)

![image](https://github.com/user-attachments/assets/1378a1e0-a570-430a-bbb7-5f48eb37fd19)

![image](https://github.com/user-attachments/assets/0d1746c4-c1bd-45ed-b2cd-e5c88704f54e)

![image](https://github.com/user-attachments/assets/e5b75f36-eb29-4a2c-9b78-8d43c65c0967)

![image](https://github.com/user-attachments/assets/c0694152-c81a-4727-b4fc-49699990392a)


